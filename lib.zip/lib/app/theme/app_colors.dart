import 'package:flutter/material.dart';

class AppColors {
  static const main = Color(0xffFFFFFF);
  static const primary = Color(0xffE87A2D);
  static const animatedButtonColor = Color(0xffE8701C);
  static const surgeText = Color(0xffD36F29);
  static const surgeContainer = Color(0xffF8D6BE);
  static const textColor = Color(0xff000000);
  static const textColor2 = Color(0xff575757);
  static const searchtext = Color(0xff8A8A8A);
  static const searchtextField = Color(0xffE6E6E6);
  static const appliancesContainer = Color(0xffF8FAFD);
  static const appliancestext = Color(0xff0B1A33);
  static const appliancestext2 = Color(0xff2D5A9E);
  static const addAppliancesrest = Color(0xffBEBEBE);
  static const usagePatternContainer = Color(0xffEAEFF5);
  static const usagePatternContainer2 = Color(0xffF7F4EF);
  static const usagePatternContainerText = Color(0xff1D7A4E);
  static const navColor = Color(0xFF112244);
  static const kitchen = Color(0x59FDF2EA);
  static const white2 = Color(0xfff7f7f7);
  static const black2 = Color(0xff333333);
  static const purpleColor = Color(0xFF6C34E8);
  static const greenColor = Color(0xFF117C4B);
  static const blueColor = Color(0xFF4C58D2);
  static const successGreen = Color(0xFF3B974B);
  static const googleBgCreate = Color(0xFFFDF2EA);
  static const googleBgLogin = Color(0xFFFDF2EA);
  static const black = Color(0xFF000000);
  static const white = Color(0xFFFFFFFF);
  static const grey = Color(0xFF9E9E9E);
  static const grey400 = Color(0xFFBDBDBD);
  static const grey600 = Color(0xFF757575);
  static const grey700 = Color(0xFF616161);

}